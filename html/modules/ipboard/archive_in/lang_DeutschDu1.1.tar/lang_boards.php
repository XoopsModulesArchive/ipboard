<?php

$lang = array (

'qli_title'  => "Quick Login",
'qli_name'   => "Benutzername",
'qli_go'     => "Ok",

by					=>	"von",

'calender_f_title'     => "Kalender Eintr�ge in den n�chsten %s Tagen",

'no_calendar_events' => "Es gibt keine Kalender Eintr�ge",

'newslink'           => "letzte Nachrichten: ",

'welcome_back_text'  => "Willkommen, Dein letzter Besuch war am",

'sm_today_posters'   => "Die heutigen Top 10 Poster",
'sm_all_posters'     => "Die Top 10 Poster insgesamt",
'sm_forum_leaders'   => "Das Moderatoren Team",
'sm_todays_posts'    => "Heutige aktive Themen",

protected_forums					=>	"Gesch�tzte Foren",
no_birth_users					=>	"Heute hat kein Mitglied Geburtstag",
total_forums					=>	"Gesamt Foren:",
public_forums					=>	"�ffentliche Foren",
public_members                  =>  "Mitglieder",

'total_word_string'             =>  "Wir haben insgesamt <b><#posts#></b> Beitr�ge<br> <b><#reg#></b> registrierte Mitglieder<br>Neuestes Mitglied: <b><a href='<#link#>'><#mem#></a></b>",


'birthday_header'       => "Mitglieder Geburtstage",

replies					=>	"Antworten",
board_stats					=>	"Board Statistik",

guests					=>	"G�ste",
posts					=>	"Beitr�ge",
total_of					=>	"hat insgesamt",
browser_user_list					=>	"Komplette Liste ansehen",

forum_leader					=>	"Forum moderiert von: ",
birth_user					=>	"Mitglied feiert heute seinen/ihren Geburtstag",
forum_users					=>	"Aktive Benutzer in diesem Forum",
forums					=>	"Foren",
restricted_forums					=>	"Geschlossene Foren",
invite_submit					=>	"Start!",
all_times					=>	"Alle Zeiten",
new_posts					=>	"Neue Beitr�ge",
anon_members					=>	"Anonyme Mitglieder",
d_post_read					=>	"Alle Beitr�ge als gelesen markieren",
last_post_info					=>	"Letzter Beitrag",
birth_users					=>	"Mitglieder feiern heute Ihren Geburtstag",
forum_off					=>	"Nur Leseberechtigung",

cat_name					=>	"Forum",
in					=>	"Thema",
registered_mems					=>	"Registrierte Mitglieder",
topics					=>	"Themen",
f_protected					=>	"<i>Gesch�tztes Forum</i>",
d_delete_cookies					=>	"Cookies l�schen",
forum_icons					=>	"Forum Symbole",



info					=>	"Information",
active_users					=>	"aktive Benutzer in den letzten %s Minuten",

f_none					=>	"----",
most_online					=>	"Online Rekord: <b><#NUM#></b> Benutzer, am <b><#DATE#></b>",
no_new					=>	"Keine neuen Beitr�ge",

);
?>