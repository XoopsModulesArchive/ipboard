<?php

$lang = array (

'cp_error_move' => "Stelle sicher das Quell und Zielforum existieren, die Themen f�r Antworten freigegeben sind, Du die Erlaubnis hast die Themen in das Forum zu verschieben und dass das Quellforum nicht dasselbe wie das Zielforum ist",

'cp_tmove_start' => "Themen vom Forum verschieben:",
'cp_tmove_to'    => "Zielforum ausw�hlen",
'cp_tmove_end'   => "Ausgew�hlte Themen verschieben",

'cp_js_delete'  => "Bist Du sicher das Du diese Themen l�schen m�chtest?",

'cp_redirect_topics' => "Themen aktualisiert, zur�ck zur Themenliste",

'cp_err_no_topics' => "Achte darauf das eine Checkbox aktiviert ist bevor Du weitermachst",

'new_show_forum' => "Forum in neuem Fenster anzeigen",

'fv_no_topics' => "Es gibt keine anzuzeigenden Themen, oder das Forum ist f�r neue Themen deaktiviert",

'cp_redirect_mod_topics'  => "Themen/Beitr�ge wurden genehmigt oder gel�scht - Du wirst weitergeleitet um weitere zu pr�fen...",

'cp_prune'  => "Verwalte Themen in Forum: ",
'cp_prune_days' => "<b>Themen verschieben/l�schen ohne neue Beitr�ge seit [x] Tagen.</b><br>(x = Anzahl eingeben)",
'cp_prune_type' => "<b>Welche Themen verschieben/l�schen?</b>",
'cp_pday_open'  => "Nur offene Themen",
'cp_pday_closed' => "Nur geschlossene Themen",
'cp_pday_link'   => "Nur verlinkte Themen",
'cp_pday_all'    => "Alle Thementypen",
'cp_prune_replies' => "<b>..mit weniger als [x] Antworten</b><br>(Leerlassen zum l�schen ohne Antworten zu beachten)",
'cp_prune_member' => "<b>...er�ffnet von Mitglied</b><br>(Leerlassen zum l�schen ohne Mitglieder zu beachten)",
'cp_prune_sub1'   => "Form pr�fen",
'cp_prune_sub2'   => "Forum beschneiden!",
'cp_action'       => "<b>Aktion</b>",
'cp_ac_prune'     => "NUR BESCHNEIDEN; NICHT L�SCHEN",
'cp_prune_text'   => "Du kannst Themen l�schen oder in ein anderes Forum verschieben. Um Themen zu verschieben w�hle ein Zielforum aus dem Drop Down Men� aus. Um Themen zu l�schen w�hle NUR BESCHNEIDEN aus dem Drop Down Men�.",
'cp_pages'        => "Seite: ",
'cp_error_no_mem' => "Es kann kein Mitglied mit dem Namen gefunden werden, bitte versuche es erneut",
'cp_error_no_topics' => "Es gibt keine anstehenden Themen in diesem Forum die auf Moderation warten.",
'cp_total_topics'    => "Themen in diesem Forum",
'cp_total_match'     => "Zu verschiebende/l�schende Themen",
'cp_check_result'    => "Pr�fergebnis",
'cp_check_text'      => "Nur weitermachen wenn das Ergebnis zufriedenstellend ist.",
'cp_mod_topics_title2' => "Moderiere neue Themen in: ",
'cp_mod_posts_title2' => "Moderiere neue Beitr�ge in: ",
'cp_prune_domove'    => "Themen verschieben!",
'cp_prune_dorem'     => "Themen entfernen!",
'cp_same_forum'      => "Du kannst nicht ins selbe Forumm verschieben",
'cp_no_forum'        => "Dies ist kein g�ltiges Zielforum",
'cp_3_title'         => "Thementitel",
'cp_3_replies'       => "Anstehende Antworten",
'cp_3_approveall'    => "Alle zustimmen",
'cp_3_viewall'       => "Anstehendes verwalten",
'cp_3_postno'        => "Beitrag #",

'cp_err_no_f'        => "Es wurde kein Forum ausgew�hlt, oder das ausgew�hlte existiert nicht, gehe zur�ck und versuche es erneut",
'cp_err_no_p'        => "Du hast keine Erlaubnis die Themen in diesem Forum zu betrachten",

'cp_error_no_subforum' => "Du kannst kein Unterforum als Zielforum ausw�hlen",

'cp_1_approve'   => "Zustimmen",
'cp_1_remove'    => "L�schen",
'cp_1_leave'     => "Verlassen",
'cp_1_selected'  => "Ausgew�hlte Beitr�ge",
'cp_1_go'        => "Diese Beitr�ge verwalten",

'cp_results'        => "Ergebnis",
'cp_result_move'    => "Anzahl der verschobenen Themen: ",
'cp_result_del'     => "Anzahl der gel�schten Themen: ",

'cp_edit_user' => "Ein Benutzerprofil bearbeiten",
'cp_find_user' => "Gib den Benutzernamen oder Anfangsbuchstaben des Namens ein den Du bearbeiten m�chtest",
'cp_find_submit' => "Benutzer finden",
'cp_find_2_user' => "Mitglied ausw�hlen",
'cp_find_2_submit' => "Benutzerprofil bearbeiten",
'cp_no_matches'    => "Es gibt keine Daten zu der eingegebenen Suche, bitte versuch es erneut",
'cp_admin_user'    => "Du kannst kein Administrator Profil im Mod CP bearbeiten",
'cp_no_perms'      => "Du hast keine Erlaubnis f�r diese Aktion.",

'cp_remove_av'     => "Benutzer Avatar l�schen?",
'cp_edit_website'  => "Webseite",
'cp_edit_location' => "Ort",
'cp_edit_signature' => "Signatur",
'cp_edit_interests' => "Interessen",



'cp_mod_in'  => "Aktuelles Forum",
'cp_topics_wait' => "Unerledigte Themen Moderation",
'cp_posts_wait'  => "Unerledigte Beitrag Moderation",

'cp_modcp_ptitle' => "Moderatoren CP",

'cp_modcp_home'  => "Moderatoren CP Start",

'cp_error'       =>  "Mod CP Nachricht",
'cp_welcome'     =>  "Willkommen!",
'cp_welcome_text' => "Willkommen im Moderatoren CP.<br>Hier kannst Du Foren, Themen und Beitr�ge moderieren, verschieben, l�schen oder anstehende Themen oder Beitr�ge freigeben.",


'cp_mod_topics'        => "Neue Themen moderieren",
'cp_mod_posts'         => "Neue Beitr�ge moderieren",

'cpt_close'  => "Themen schlie�en",
'cpt_open'   => "Themen �ffnen",
'cpt_pin'    => "Themen pinnen",
'cpt_unpin'  => "Themen l�sen",
'cpt_move'   => "Themen verschieben",
'cpt_delete' => "Themen l�schen",


'cp_prune_posts'       => "Massen verschieben /Themen bearbeiten",


'cp_user_edit'         => "Benutzerprofil bearbeiten",

'title_manage_forums'  => "Foren verwalten",

'f_q_posts'            => "Anstehende Beitr�ge",
'f_q_topics'           => "Anstehende Themen",
'f_select'             => "Ausw�hlen",

'f_w_selected'         => "Ausgew�hlte Foren:",
't_w_selected'         => "Ausgew�hlte Themen:",
'f_go'                 => "Start!",

'menu_forums' => "Foren verwalten",
'menu_users'  => "Mitglieder verwalten",
'menu_ip'     => "IP Adress Tools",

'mod_opts'    => "Moderatoren Optionen",

'ip_desc_text' => "<b>Die folgenden Optionen k�nnen benutzt werden</b><br><br><b> IP Adresse</b> <u> aufl�sen</u>: Hier kannst Du weitere Informationen zu IP Adressen abfragen (Beachte, Du musst alle Angaben zur IP Adresse angeben um das Tool benutzen zu k�nnen.)<br><b><u>Beitr�ge finden</u> mit dieser IP</b>: Es werden alle Beitr�ge gesucht die mit der IP Adresse �bereinstimmen<br><b><u>Mitglieder finden</u> die sich mit dieser IP Adresse registriert haben</b>: Es werden alle Mitglieder gesucht die sich mit dieser IP Adresse registriert haben",
'ip_warn_text' => "<b>Bitte beachte</b>: Du kannst als Wildcard '*' f�r den letzten Eintrag der IP Adresse angeben.<br>Als Beispiel, 127.10.*.* Als Ergebnis werden alle IP Adressen angezeigt die mit 127. starten.<br><br>Als Fehler wird gewertet wenn Du eine Wildcard in der Mitte der IP Adresse eingibst. Als Beispiel, 127.*.0.1 wird als Fehler gewertet.",
'ip_enter'     => "<b>IP Adresse eingeben</b><br>(Benutze die TAB Taste um in das n�chste Feld zu gelangen)",
'ip_submit'    => "Starte Tool",

'ip_resolve'   => "Vornehmen",
'ip_posts'     => "Beitrag finden",
'ip_members'   => "Mitglied finden",

'cp_error_ip'  => "Stelle sicher das die ersten beiden Felder der IP Adresse angegeben wurden, und keine Wildcard in der Mitte eingetragen ist",
'cp_error_resolveip' => "Du musst die komplette IP Adresse eingeben um dieses Tool benutzen zu k�nnen.",
'ip_resolve_result' => "Der Hostname f�r %s ist <b>%s</b><br><br>Abfrage starten <a href='http://www.nic.com/cgi-bin/whois.cgi' target='_blank'>nic.com</a> um mehr Informationen duch WHOIS zu erhalten.",

'cp_safe_fail' => "Die Suchaktion fehlt oder es wurde kein Ergebnis gefunden. Wenn der PHP Save Modus an ist, kannst Du nicht alle Tools nutzen",

'cp_no_matches' => "Kein Suchergebnis gefunden, gehe zur�ck und �ndere die Suchkriterien",

'ipm_title'  => "Suchergebnis der Mitglieder IP Adresse",
'ipm_name'   => "Name",
'ipm_ip'     => "IP Adresse",
'ipm_posts'  => "Beitr�ge",
'ipm_reg'    => "Registrierungs Datum",
'ipm_options' => "Optionen",

'ipm_edit'  => "Mitglied bearbeiten",
'ipm_view'  => "Profil ansehen",

'ipp_found' => "Deine Suche ergab die folgende Anzahl Beitr�ge:",
'ipp_click' => "Hier klicken um das Ergebnis in einem neuen Fenster anzusehen",







'leave_link'   => "Belasse einen Link im original Forum zum neuen Thema?",

'yes' => "Ja",
'no'  => "Nein",

'move_exp' => "Bitte Zielforum und die Methode des Verschiebens ausw�hlen",





);
?>