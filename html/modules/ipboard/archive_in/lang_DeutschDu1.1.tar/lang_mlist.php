<?php

$lang = array (

'ch_begins'     => "Name beginnt mit",
'ch_contains'   => "Name beinhaltet",
'ch_all'        => "Alle verf�gbaren suchen",
'qs_go'         => "Start!",
'member_group'   => "Gruppe",
'member_aol'   => "AOL",
'sort_by_name'   => "Mitgliedsname",
'member_joined'   => "Mitglied seit",
'member_icq'   => "ICQ",
'sorting_text'   => "Zeige <#FILTER#> nach <#SORT_KEY#> in <#SORT_ORDER#> mit <#MAX_RESULTS#> pro Seite",
'member_name'   => "Name",
'member_posts'   => "Beitr�ge",
'multi_pages'   => "Mehrere Seiten",
'sort_by_posts'   => "Gesamte Beitr�ge",
'descending_order'   => "Absteigende Sortierung",
'ascending_order'   => "Aufsteigende Sortierung",
'show_admin'   => "Administratoren",
'member_level'   => "Level",
'sort_submit'   => "Absenden",
'show_all'   => "Alle Mitglieder",
'member_email'   => "E-Mail",
'sort_by_joined'   => "Beitrittsdatum",
'sort_by_level'   => "Mitgliederlevel",
'show_staff'   => "Board Team",
'page_title'   => "Mitgliederliste",

);

?>