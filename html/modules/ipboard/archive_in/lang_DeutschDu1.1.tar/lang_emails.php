<?php

$lang = array (

'msn_send_msg'  => "Sende diesem Benutzer eine MSN Nachricht",
'msn_add_contact' => "Benutzer zum MSN  Adressbuch hinzuf�gen",

'chat_title'      => "Live Chat Hauptfenster",
'chat_help'       => "Live Chat Hilfe",

'chat_help_text'  => "Wenn Du Benutzer einer ie Version von Microsoft Windows&#153; bist und ein defektes Link symbol siehst, ben�tigst Du einen aktuellen download der Java&#153; Virtual Machine damit die Applikation l�uft. Du kannst Java&#153; f�r Deinen Browser downloaden mit einem der folgenden Links:<BR>
<BR>
        * <a href='http://www.microsoft.com/Java/vm/dl_vm40.htm?FinishURL=%2Fdownloads%2Frelease%2Easp%3Frelease'>Microsoft Virtual Machine (for MSIE)</a><BR>
        * <a href='http://java.sun.com/getjava/'>Sun Java&#153; Plugin (for Netscape, Opera, MSIE, etc..)</a><BR>
<BR>
    �ltere Versionen von Netscape z.b. v4.08, und v4.7x k�nnen diese Software nicht benutzen. Hier ist es Sinnvoll auf eine neuere Version upzudaten.  (v6.xx oder besser). <BR>
<BR>
    Benutzer hinter einer Firewall k�nnten ebenfalls Probleme bekommen und sollten in dem Fall die Netzwerk Einstellungen �berpr�fen und die Ports 9000-9009 als Client freigeben.<BR>
<BR>
    AOL Benutzer: Bei einigen AOL Benutzern kann es ebenfalls zu Problemen kommen. Hier hilft es die AOL Verbindung zu minimieren und den Internet Explorer zu starten um die Chat R�ume nutzen zu k�nnen.<BR>
<BR>",

'msn_name'      => "MSN Mitgliedsname",


'yahoo_send_msg'  => "Sende diesem Benutzer eine Yahoo Nachricht",
'yahoo_view_profile' => "Benutzer zum Yahoo  Adressbuch hinzuf�gen",
'yahoo_status'       => "Yahoo! Online Status",
'yahoo_name'      => "Yahoo! Mitgliedsname",

'report_title'   => "Bericht an Moderator senden",
'report_submit'  => "Abschicken",
'report_message' => "<b>Bericht eingeben</b><br><br>Bitte beachten: Der Moderator erh�lt einen Link zu dem Beitrag und dem Thementitel.<br><br>Diese Form bitte nur benutzen um auf Themen oder Beitr�ge aufmerksam zu machen und nicht um mit dem Moderator in Kontakt zu treten.",
'report_topic'   => "Thementitel",


'report_subject' => "Beitragsbericht",

'report_redirect' => "Der Bericht wurde abgeschickt, Du wirst nun zum Thema weitergeleitet",

'message'    => "Nachricht",
'title'    => "Ein Thema an einen Freund versenden",
'send_lang'    => "Diese E-Mail senden",
'to_name'    => "Senden an (Name der Person):",
'redirect'    => "Die E-Mail wurde versendet",
'to_email'    => "Senden an (E-Mail Adresse):",
'subject'    => "Betreff",
'submit_send'    => "E-Mail senden",
'send_email_to'    => "E-Mail senden an",
'show_address_text'    => "Mit einem Klick auf den untenstehenden Link kannst Du dem Mitglied eine Mail senden. Invision Board zeigt die E-Mail Adresse nicht im HTML Code an um Missbrauch durch \'spam bots\' zu verhindern.",
'send_header'    => ", bitte f�lle das Formular vollst�ndig aus.",
'member_address_title'    => "E-Mail Adresse des Mitglieds",
'send_title'    => "E-Mail Formular",
'msg_txt'    => "Achtung: Durch den Gebrauch dieses Formulares ist der Empf�nger in der Lage, Deine E-Mail Adresse zu sehen.",
'email_sent_txt'    => "Danke, die E-Mail wurde erfolgreich verschickt.",
'email_sent'    => "E-Mail wurde gesendet",
'invite_subject'    => "<#MEMBER_NAME#> schickt Dir diesen interessanten Hinweis",
'subs_redirect'    => "Du hast dieses Thema abonniert",
'invite_redirect'    => "Die E-Mail wurde gesendet an  ",
'sub_added'    => "Thema wurde abonniert",
'icq_title'    => "ICQ Pager",
'submit'    => "Diese Nachricht senden",
'aol_title'    => "AOL Pager",
'msg'    => "Gib Deine Nachricht ein",
'email'    => "Deine E-Mail Adresse",
'name'    => "Dein Name",
'forum_jump'    => "Forum ausw�hlen",

);

?>