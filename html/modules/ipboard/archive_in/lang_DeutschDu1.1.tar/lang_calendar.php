<?php

$lang = array (

'page_title'  => 'Kalender',
'table_title' => 'Terminkalender',

'form_submit_show' => "Zeigen",

'entry_birthdays'  => "%s Geburtstag(e)",

'post_new_event'   => "Neuen Termin eintragen",

'new_event_redirect' => "Neuer Termin wurde eingetragen",

'cal_title_events'  => "Kalender Ereignisse",

'cal_birthdays'     => "Geburtstage",

'back'              => "Zur�ck",

'private_event'     => "Privater Termin",
'public_event'      => "�ffentlicher Termin",
'restricted_event'  => "Begrenzter Termin",

'joined'  => "Seit:",
'posts'   => "Beitr�ge:",
'group'   => "Gruppe:",

'edit_event' => "Termin bearbeiten:",

'edit_event_redirect' => "Der Termin wurde bearbeitet",
'delete_event_redirect' => "Der Termin wurde <b>gel�scht</b>",

'event_date'  => "Termin Datum:",

);
?>