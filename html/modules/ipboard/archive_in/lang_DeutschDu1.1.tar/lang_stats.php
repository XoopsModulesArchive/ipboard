<?php

$lang = array (

'who_farted'    => "geschrieben in:",

'who_poster'    => "Poster",
'who_posts'     => "Beitr�ge",
'who_go'        => "Fenster schliessen & Thema �ffnen",

'todays_posters'   => "Heutige Top 10 Autoren",
'member'   => "Mitglied",
'member_posts'   => "Mitgliedsbeitr�ge gesamt",
'member_today'   => "Beitr�ge heute",
'member_joined'   => "Mitglied seit",
'member_percent'   => "% der heutigen Beitr�ge",
'total_today'   => "Gesamtbeitr�ge heute: ",
'no_info'   => "Zur Zeit sind keine Informationen verf�gbar",
'top_poster_title'   => "Heutige Top 10 Autoren",
'forum_leaders'   => "Das Moderatorenteam",
'leader_admins'   => "Admins",
'leader_global'   => "Globale Moderatoren",
'leader_mods'   => "Forummoderatoren",
'leader_name'   => "Mitgliedsname",
'leader_email'   => "E-Mail",
'leader_aol'   => "AOL",
'leader_icq'   => "ICQ",
'leader_location'   => "Wohnort",
'leader_forums'   => "Foren",
'leader_all_forums'   => "Alle Foren",

);

?>