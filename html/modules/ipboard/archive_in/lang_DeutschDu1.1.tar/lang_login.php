<?php

$lang = array (

'logged_in' => "Du bist eingeloggt und wirst zur Index Seite weitergeleitet",
'reg_log_in' => "Du bist nun registriert und eingeloggt. Du wirst zur Index Seite weitergeleitet",
'not_logged_in' => "Du bist nicht eingeloggt und wirst zur Login Seite weitergeleitet",
'reg_not_log_in' => "Du bist nun registriert und wirst zur Login Seite weitergeleitet",

'login_text'   => "Du kannst Dich erst einloggen nachdem Du Dich registriert hast.<br>Wenn Du noch nicht registriert bist, kannst Du Dich anmelden indem Du auf den Button \'Registrieren\' klickst.",
'force_login'   => "Damit Du das Board nutzen kannst, musst Du eingeloggt sein",
'wrong_name'   => "Es gibt keinen Benutzer mit diesem Namen <#NAME#>. Bist Du sicher das der Name stimmt?",
'please_log_in'   => "Trage bitte Deine Daten unten ein um Dich einzuloggen",
'cookie_no'   => "Nein",
'options'   => "Optionen",
'wrong_pass'   => "Das Passwort ist falsch",
'admin_force_log_in'   => "Du musst Dich einloggen, um das Board betrachten zu k�nnen.",
'log_in_submit'   => "Jetzt einloggen",
'anon_name'   => "Nein",
'add_name'   => "ja",
'errors_found'   => "Folgender Fehler wurde gefunden:",
'thanks_for_logout'   => "Du bist nun ausgeloggt",
'forgot_pass'   => "Passwort vergessen?",
'thanks_for_login'   => "Du bist nun eingeloggt!",
'log_out'   => "Ausloggen",
'enter_name'   => "Benutzernamen eingeben",
'cookies'   => "<b>Cookies?</b>M�chtest Du Deinen Benutzernamen und Dein Passwort auf Deinem Computer verschl�sselt speichern? Dann brauchst Du Dich nicht immer erneut einzuloggen.",
'enter_pass'   => "Passwort eingeben",
'pass_link'   => "Hier klicken!",
'privacy'   => "<b>Achtung</b>, m�chtest Du in der Liste der aktiven Benutzer erscheinen?",
'cookie_yes'   => "Ja",
'blank_fields'   => "Gib Deinen Namen und Dein Passwort ein",
'log_out_submit'   => "jetzt Ausloggen",
'log_in'   => "Einloggen",

);

?>