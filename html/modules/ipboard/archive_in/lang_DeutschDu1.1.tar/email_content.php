<?php


$EMAIL['header'] = <<<EOF

EOF;

$EMAIL['footer'] = <<<EOF

Das <#BOARD_NAME#> Team.
<#BOARD_ADDRESS#>

EOF;

$EMAIL['pm_notify'] = <<<EOF
<#NAME#>,

<#POSTER#> hat Dir eine Private Nachricht mit dem Betreff: "<#TITLE#>" gesendet.

Um die Nachricht zu lesen benutze folgenden Link:

<#BOARD_ADDRESS#><#LINK#>


EOF;

$EMAIL['send_text'] = <<<EOF
Ich habe mir gedacht, diese Seite k�nnte f�r dich interessant sein: <#THE LINK#>

Von,

<#USER NAME#>
EOF;

$EMAIL['report_post'] = <<<EOF
<#MOD_NAME#>,

Diese E-Mail wurde Dir von <#USERNAME#> �ber den "Berichte Moderator �ber diesen Beitrag" Link geschickt.

------------------------------------------------
Thema: <#TOPIC#>
------------------------------------------------
Link zum Beitrag: <#LINK_TO_POST#>
------------------------------------------------
Bericht:

<#REPORT#>

------------------------------------------------

EOF;

$EMAIL['pm_archive'] = <<<EOF
<#NAME#>,
Diese E-Mail wurde Dir von <#BOARD_ADDRESS#> gesendet.

Deine archivierten PM`s wurden in eine Datei gepackt und an diese Nachricht angeh�ngt.


EOF;

$EMAIL['reg_validate'] = <<<EOF
<#NAME#>,
Diese E-Mail wurde Dir von <#BOARD_ADDRESS#> gesendet.

Du erh�lst diese E-Mail, da diese E-Mail Adresse zur Registrierung auf unserem Forum verwendet wurde.
Solltest Du dich nicht auf unserem Forum angemeldet haben, bitte ignoriere diese E-Mail. Du musst dich nicht abmelden oder irgendetwas anderes tun.


------------------------------------------------
     Instruktionen f�r die Aktivierung unten
------------------------------------------------
Danke f�r deine Registrierung.
Wir m�chten, dass Du Deine Anmeldung "best�tigst", damit wir sicher gehen k�nnen, dass die von dir angegebene E-Mail Adresse korrekt ist. Dies sch�tzt vor ungewolltem Spam und sonstigem Missbrauch.
Zur Aktivierung Deines Accounts, klicke einfach auf den folgenden Link:

<#THE_LINK#>

(AOL E-Mail Benutzer m�ssen den Link vielleicht kopieren und im Browser wieder einf�gen).

------------------------------------------------
            EIN FEHLER TRITT AUF
------------------------------------------------

Sollte die Best�tigung Deiner Anmeldung durch das Klicken auf den Link nicht funktioniert haben, bitte besuche diese Seite:

<#MAN_LINK#>

Du wirst nach einer ID und einem Best�tigungs-Schl�ssel gefragt. Dieser lautet:

Benutzer ID: <#ID#>

Best�tigungs-Schl�ssel: <#CODE#>

Bitte kopiere diese Werte und f�ge sie in die richtigen Felder durch Einf�gen oder manuelle Eingabe ein.

Solltest Du Deine Anmeldung immer noch nicht best�tigen k�nnen, kann es m�glich sein, dass dein Account entfernt wurde.
Ist dies der Fall, bitte kontaktiere einen Administrator um dieses Problem zu l�sen.

Danke f�r Deine Anmeldung und habe Spa�!

EOF;

$EMAIL['admin_newuser'] = <<<EOF
Sehr geehrter Administrator:

Diese E-Mail wurde verschickt, da sich ein neuer Benutzer angememeldet hat!

<#MEMBER_NAME#> hat seine Anmeldung um <#DATE#> beendet.

Du kannst diese Benachrichtigung im AdminCP abstellen.
EOF;

$EMAIL['lost_pass'] = <<<EOF
<#NAME#>,
Diese E-Mail wurde Dir von <#BOARD_ADDRESS#> geschickt.

Du erh�ltst diese Nachricht, weil die "Passwort Vergessen"-Routine eingeleitet wurde.

WICHTIG! SOLLTEST DU DIESE ROUTINE NICHT VERLANGT HABEN, 
MACH NICHT WEITER UND L�SCHE DIESE E-MAIL!

FOLGE DEN UNTERSTEHENDEN ANWEISUNGEN NUR, 
WENN DU DEIN PASSWORT ZUR�CKGESETZT HABEN M�CHTEST.

------------------------------------------------
        ANWEISUNGEN FOLGEN UNTEN
------------------------------------------------

Wir m�chten, dass Du Deine "Passwort Vergessen" Anfrage "best�tigst", damit wir sicher gehen k�nen, dass die von Dir angegebene E-Mail Adresse korrekt ist. Dies sch�tzt vor ungewollten Spam und sonstigen Mi�brauch.

Solltest Du das Fenster nicht offen haben, klicke bitte auf den folgenden Link:

<#MAN_LINK#>

(AOL E-Mail Benutzer m�ssen den Link vielleicht kopieren und im Browser wieder einf�gen).

Du wirst nach einer ID und einem Best�tigungs-Schl�ssel gefragt. Dieser lautet:

Benutzer ID: <#ID#>

Best�tigungs-Schl�ssel: <#CODE#>

Bitte kopiere diese Werte und f�ge sie in die richtigen Felder durch Einf�gen oder manuelle Eingabe ein.

Sobald die Aktivierung fertig gestellt ist, kannst Du Dich mit Deinem neuen Passwort (untenstehend) wieder einloggen. Du kannst dieses Passwort jederzeit in Deinem pers�nlichen Kontroll Panel �ndern.

------------------------------------------------
             DEIN NEUES PASSWORT
------------------------------------------------

Dein neues Passwort lautet: <#PASSWORD#>

Verwahre dieses Passwort sicher. Vergiss bitte nicht, dass Du Deinen Account wieder aktivieren musst, bevor Du dieses Passwort verwenden kannst.

------------------------------------------------
             EIN FEHLER TRITT AUF
------------------------------------------------

Solltest Du Deinen Account nicht wieder aktivieren k�nnen, kann es m�glich sein, dass Dein Account entfernt wurde oder dass Du in einem anderen Aktivierungs-Prozess bist, wie z.B. Registrierung oder E-Mail Adressenwechsel.
Sollte dies der Fall sein, bitte beende diesen Prozess vorher.
Sollte dieses Problem weiterhin bestehen, kontaktiere einen Administrator um dieses Problem zu l�sen.


EOF;

$EMAIL['newemail'] = <<<EOF
<#NAME#>,
Diese E-Mail wurde Dir von <#BOARD_ADDRESS#> gesendet.

Du erh�ltst diese E-Mail weil Du eine andere E-Mail Adresse verwenden m�chtest.

------------------------------------------------
        ANWEISUNGEN FOLGEN UNTEN
------------------------------------------------

Wir m�chten, dass Du Deine "E-Mail Adressen�nderung" Anfrage "best�tigst", damit wir sicher gehen k�nen, dass die von Dir angegebene E-Mail Adresse korrekt ist. Dies sch�tzt vor ungewolltem Spam und sonstigen Missbrauch.

Solltest Du das Fenster nicht offen haben, klicke bitte auf den folgenden Link:

<#MAN_LINK#>

(AOL E-Mail Ben�tzer m�ssen den Link vielleicht kopieren und im Browser wieder einf�gen).

Du wirst nach einer ID und einem Best�tigungs-Schl�ssel gefragt. Dieser lautet:

Benutzer ID: <#ID#>

Best�tigungs-Schl�ssel: <#CODE#>

Bitte kopiere diese Werte und f�ge sie in die richtigen Felder durch Einf�gen oder manuelle Eingabe ein.

Sobald die Aktivierung fertig gestellt ist, wird Deine neue E-Mail Adresse in unserer Datenbank gespeichert.


------------------------------------------------
            EIN FEHLER TRITT AUF
------------------------------------------------

Solltest Du Deinen Account nicht wieder aktivieren k�nnen, kann es m�glich sein, dass Dein Account entfernt wurde oder dass Du in einem anderen Aktivierungs-Prozess bist, wie z.B. Registrierung oder E-Mail Adressenwechsel.
Sollte dies der Fall sein, bitte beende diesen Prozess vorher.
Sollte dieses Problem weiterhin bestehen, kontaktiere einen Administrator um dieses Problem zu l�sen.

EOF;

$EMAIL['forward_page'] = <<<EOF
<#TO_NAME#>


<#THE_MESSAGE#>

---------------------------------------------------
Beachte bitte das <#BOARD_NAME#> nicht f�r den Inhalt dieser Mitteilung verantwortlich ist.
---------------------------------------------------

EOF;

$EMAIL['subs_with_post'] = <<<EOF
<#NAME#>,

<#POSTER#> hat einen Beitrag zu einem Deiner abonnierten Themen geschrieben. "<#TITLE#>".

----------------------------------------------------------------------
<#POST#>
----------------------------------------------------------------------

Das Thema findest Du hier:
<#BOARD_ADDRESS#>?act=ST&f=<#FORUM_ID#>&t=<#TOPIC_ID#>



Es kann sein, dass dort mehr als nur eine neue Antwort zu dem Thema geschrieben wurde. Um aber unn�tige E-Mails zu vermeiden wird t�glich nur eine Benachrichtigung �ber Deine Inbox geschickt.

Abonnement l�schen:
--------------

Wenn Du keine Benachrichtigung mehr zu diesem Thema erhalten m�chtest, kannst Du das Abonnement in Deinem Kontroll Panel l�schen.

EOF;

$EMAIL['subs_new_topic'] = <<<EOF
<#NAME#>,

<#POSTER#> hat ein neues Thema mit dem Titel "<#TITLE#>" im Forum "<#FORUM#>" er�ffnet.

Das Thema findest Du unter:
<#BOARD_ADDRESS#>?act=ST&f=<#FORUM_ID#>&t=<#TOPIC_ID#>

Es kann sein, dass dort mehr als nur eine neue Antwort zu dem Thema geschrieben wurde. Um aber unn�tige E-Mails zu vermeiden wird t�glich nur eine Benachrichtigung �ber Deine Inbox geschickt.
<#BOARD_ADDRESS#>?act=Track&f=<#FORUM_ID#>&t=<#TOPIC_ID#>


Abonnement l�schen:
--------------

Wenn Du keine Benachrichtigung mehr zu diesem Thema erhalten m�chtest, kannst Du das Abonnement in Deinem Kontroll Panel l�schen.
EOF;

$EMAIL['subs_no_post'] = <<<EOF
<#NAME#>,

<#POSTER#> hat einen Beitrag zu einem Deiner abonnierten Themen geschrieben. "<#TITLE#>".

Das Thema findest Du hier:
<#BOARD_ADDRESS#>?act=ST&f=<#FORUM_ID#>&t=<#TOPIC_ID#>

Es kann sein, dass dort mehr als nur eine neue Antwort zu dem Thema geschrieben wurde. Um aber unn�tige E-Mails zu vermeiden wird t�glich nur eine Benachrichtigung �ber Deine Inbox geschickt.

Abonnement l�schen:
--------------

Wenn Du keine Benachrichtigung mehr zu diesem Thema erhalten m�chtest, kannst Du das Abonnement in Deinem Kontroll Panel l�schen.

EOF;

$EMAIL['email_member'] = <<<EOF
<#MEMBER_NAME#>,

Diese E-Mail wurde Dir von  <#FROM_NAME#> �ber <#BOARD_ADDRESS#>)
gesendet.

<#MESSAGE#>

---------------------------------------------------
Beachte bitte, dass <#BOARD_NAME#> nicht f�r den Inhalt der Nachricht verantwortlich ist.
---------------------------------------------------


EOF;

$EMAIL['complete_reg'] = <<<EOF
Registrierung erfolgreich!

Ein Administrator hat soeben Deine Registrierung oder E-mail Adress�nderung von <#BOARD_NAME#> best�tigt. Du kannst Dich nun mit Deinem Benutzernamen und Passwort unter <#BOARD_ADDRESS#> einloggen.

EOF;


?>