<?php


$lang['page_title']  = "Assistent";
$lang['log_in_needed']  = "Einloggen erfordert";
$lang['no_guests']  = "Diese Funktion steht nur registrierten Benutzern zur Verf�gung.<br><br>Wenn Sie registrierter Benutzer sind, loggen Sie sich bitte ein.";
$lang['log_in']  = "Einloggen";
$lang['lin_name']  = "Benutzername";
$lang['lin_pass']  = "Passwort";
$lang['reg_text']  = "Wenn Sie kein registrierter Benutzer sind, m�ssen Sie sich zun�chst registrieren um diese Funktion nutzen zu k�nnen.";
$lang['reg_link']  = "Registrieren";
$lang['close_win']  = "Fenster schliessen";
$lang['refresh']  = "Aktualisieren";
$lang['show_me']  = "Zeige...";
$lang['sm_today_posters']  = "Heutige Top 10 Poster";
$lang['sm_all_posters']  = "Top 10 Poster insgesamt";
$lang['sm_forum_leaders']  = "Das Moderatoren Team";
$lang['sm_todays_posts']  = "Heutige aktive Themen";
$lang['sm_my_last_posts']  = "Ihre letzten 10 Beitr�ge";
$lang['while_away']  = "Seit Ihrem letzten Besuch...";
$lang['no_new_posts']  = "Keine neuen Beitr�ge";
$lang['new_posts']  = "Es gibt %s neue Beitr�ge.";
$lang['view_link']  = "Anzeigen";
$lang['my_replies']  = "%s Beitr�ge sind Antworten auf Ihre Themen.";
$lang['none']  = "keine";
$lang['search_forums']  = "Suche Beitr�ge nach...";
$lang['search_help']  = "Suche Hilfeseiten nach...";
$lang['go']  = "Start!";

?>