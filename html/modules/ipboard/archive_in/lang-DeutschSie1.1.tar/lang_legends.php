<?php

$lang = array (

'emo_title' => "Emoticons",
'emo_type'  => "Code",
'emo_img'   => "Image",

'fu_title'  => "Benutzer finden",
'fu_close_win' => "Fenster schliessen",
'fu_enter_name' => "Name oder Teile des Namens eingeben",
'fu_search_but' => "Suche",

'fu_error'      => "Fehler",

'fu_no_data'    => "Sie m�ssen den Namen oder Teile des Namens angeben",
'fu_no_match'   => "Kein Suchergebnis gefunden.",
'fu_kc_loads'   => "Mehr als 100 Benutzer gefunden, bitte Suche verfeinern.",
'fu_back'       => "Zur�ck",
'fu_add_mem'    => "Benutzername eingeben",
'fu_add_desc'   => "W�hlen Sie einen Namen aus dem Drop Down Men� und klicken Sie auf den Button um den Namen hinzuzuf�gen.",

);
?>