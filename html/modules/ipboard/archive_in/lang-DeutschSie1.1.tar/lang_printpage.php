<?php


$lang['end']  = "Ende";
$lang['forum']  = "Forum";
$lang['on']  = "am";
$lang['title']  = "Druckbare Version des Themas";
$lang['by']  = "Geschrieben von";
$lang['start']  = "Gestartet von";
$lang['topic']  = "Thema";
$lang['tvo_title']  = "Themenansicht Optionen f�r:";
$lang['o_print_title']  = "Drucker freundliche Version";
$lang['o_print_desc']  = "Das Thema wird in einem Display angezeigt und kann ausgedruckt werden. Kein Download notwendig.";
$lang['o_html_title']  = "Download HTML Version";
$lang['o_html_desc']  = "Dies erlaubt Ihnen eine HTML Version des Themas auf Ihre Festplatte zu kopieren.";
$lang['o_word_title']  = "Download Microsoft Word Version";
$lang['o_word_desc']  = "Dies erlaubt Ihnen eine editierbare Word Version des Themas auf Ihre Festplatte zu kopieren.";
$lang['back_topic']  = "Zur�ck zum Thema";
$lang['topic_here']  = "Hier klicken um das Thema im Original Format zu betrachten.";

?>