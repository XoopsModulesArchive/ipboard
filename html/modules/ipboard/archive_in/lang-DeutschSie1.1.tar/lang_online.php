<?php

$lang = array (

'WHERE_SF'   => "Ansicht Forum:",
'WHERE_SR'   => "Ansicht Forumregeln:",
'WHERE_ST'   => "Ansicht des Themas:",
'WHERE_Login'   => "Loggt sich ein...",
'WHERE_Post'   => "Schreibt einen Beitrag:",
'WHERE_Reg'   => "Registrierung...",
'WHERE_Online'   => "Ansicht Onlineliste",
'WHERE_Members'   => "Ansicht Mitgliederliste",
'WHERE_Help'   => "Ansicht Hilfethemen",
'WHERE_Search'   => "Suche...",
'WHERE_Print'   => "Druckt Thema:",
'WHERE_Forward'   => "verschickt Thema per E-Mail:",
'WHERE_Msg'   => "Benutzt Messenger",
'WHERE_UserCP'   => "Benutzt Kontroll Center",
'WHERE_Mail'   => "Mitglied ein E-Mail schreiben",
'WHERE_Invite'   => "Laden Sie einen Freund ins Forum ein",
'WHERE_ICQ'   => "Mitglied �ber ICQ kontaktieren",
'WHERE_AOL'   => "Mitglied �ber AIM kontaktieren",
'WHERE_Profile'   => "Ansicht Mitgliederprofile",
'WHERE_Stats'   => "Ansicht Statistiken",
'WHERE_ModCP'   => "Benutzt Moderatoren CP:",
'member_name'   => "Mitgliedername",
'guest'   => "Gast",
'board_index'   => "Ansicht Boardindex",
'n_a'   => "[ N/A ]",
'pages'   => "Seiten:",
'time'   => "Zeit",
'where'   => "Ort",
'user_ops'   => "Optionen",
'page_title'   => "Onlinebenutzer",

);

?>