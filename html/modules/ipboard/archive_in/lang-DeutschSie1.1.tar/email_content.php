<?php


$EMAIL['header'] = <<<EOF

EOF;

$EMAIL['footer'] = <<<EOF

Das <#BOARD_NAME#> Team.
<#BOARD_ADDRESS#>

EOF;

$EMAIL['pm_notify'] = <<<EOF
<#NAME#>,

<#POSTER#> hat Ihnen eine Private Nachricht mit dem Betreff: "<#TITLE#>" gesendet.

Um die Nachricht zu lesen benutzen Sie folgenden Link:

<#BOARD_ADDRESS#><#LINK#>


EOF;

$EMAIL['send_text'] = <<<EOF
Ich habe mir gedacht, diese Seite k�nnte f�r Sie interessant sein: <#THE LINK#>

Von,

<#USER NAME#>
EOF;

$EMAIL['report_post'] = <<<EOF
<#MOD_NAME#>,

Diese E-Mail wurde Ihnen von <#USERNAME#> �ber den "Berichte Moderator �ber diesen Beitrag" Link geschickt.

------------------------------------------------
Thema: <#TOPIC#>
------------------------------------------------
Link zum Beitrag: <#LINK_TO_POST#>
------------------------------------------------
Bericht:

<#REPORT#>

------------------------------------------------

EOF;

$EMAIL['pm_archive'] = <<<EOF
<#NAME#>,
Diese E-Mail wurde Ihnen von <#BOARD_ADDRESS#> gesendet.

Ihre archivierten PM`s wurden in eine Datei gepackt und an diese Nachricht angeh�ngt.


EOF;

$EMAIL['reg_validate'] = <<<EOF
<#NAME#>,
Diese E-Mail wurde Ihnen von <#BOARD_ADDRESS#> gesendet.

Sie erhalten diese E-Mail, da diese E-Mail Adresse zur Registrierung auf unserem Forum verwendet wurde.
Sollten Sie sich nicht auf unserem Forum angemeldet haben, bitte ignorieren Sie diese E-Mail. Sie m�ssen sich nicht abmelden oder irgendetwas anderes tun.


------------------------------------------------
     Instruktionen f�r die Aktivierung unten
------------------------------------------------
Danke f�r Ihre Registrierung.
Wir m�chten, dass Sie ihre Anmeldung "best�tigen", damit wir sicher gehen k�nnen, dass die von Ihnen angegebene E-Mail Adresse korrekt ist. Dies sch�tzt vor ungewolltem Spam und sonstigem Missbrauch.
Zur Aktivierung Ihres Accounts, klicken Sie einfach auf den folgenden Link:

<#THE_LINK#>

(AOL E-Mail Benutzer m�ssen den Link vielleicht kopieren und im Browser wieder einf�gen).

------------------------------------------------
            EIN FEHLER TRITT AUF
------------------------------------------------

Sollte die Best�tigung Ihrer Anmeldung durch das Klicken auf den Link nicht funktioniert haben, bitte besuchen Sie diese Seite:

<#MAN_LINK#>

Sie werden nach einer ID und einem Best�tigungs-Schl�ssel gefragt. Dieser lautet:

Benutzer ID: <#ID#>

Best�tigungs-Schl�ssel: <#CODE#>

Bitte kopieren Sie diese Werte und f�gen Sie sie in die richtigen Felder durch Einf�gen oder manuelle Eingabe ein.

Sollten Sie Ihre Anmeldung immer noch nicht best�tigen k�nnen, kann es m�glich sein, dass Ihr Account entfernt wurde.
Ist dies der Fall, bitte kontaktieren Sie einen Administrator um dieses Problem zu l�sen.

Danke f�r Ihre Anmeldung und viel Spa�!

EOF;

$EMAIL['admin_newuser'] = <<<EOF
Sehr geehrter Administrator:

Diese E-Mail wurde verschickt, da sich ein neuer Benutzer angemeldet hat!

<#MEMBER_NAME#> hat seine Anmeldung um <#DATE#> beendet.

Sie k�nnem diese Benachrichtigung im AdminCP abstellen.
EOF;

$EMAIL['lost_pass'] = <<<EOF
<#NAME#>,
Diese E-Mail wurde Ihnen von <#BOARD_ADDRESS#> geschickt.

Sie erhalten diese Nachricht, weil die "Passwort Vergessen"-Routine eingeleitet wurde.

WICHTIG! SOLLTEN SIE DIESE ROUTINE NICHT VERLANGT HABEN, 
MACHEN SIE NICHT WEITER UND L�SCHEN DIESE E-MAIL!

FOLGEN SIE DEN UNTERSTEHENDEN ANWEISUNGEN NUR, 
WENN SIE IHR PASSWORT ZUR�CKGESETZT HABEN M�CHTEN.

------------------------------------------------
        ANWEISUNGEN FOLGEN UNTEN
------------------------------------------------

Wir m�chten, dass Sie Ihre "Passwort Vergessen" Anfrage "best�tigen", damit wir sicher gehen k�nen, dass die von Ihnen angegebene E-Mail Adresse korrekt ist. Dies sch�tzt vor ungewollten Spam und sonstigen Mi�brauch.

Sollten Sie das Fenster nicht offen haben, klicken Sie bitte auf den folgenden Link:

<#MAN_LINK#>

(AOL E-Mail Benutzer m�ssen den Link vielleicht kopieren und im Browser wieder einf�gen).

Sie werden nach einer ID und einem Best�tigungs-Schl�ssel gefragt. Dieser lautet:

Benutzer ID: <#ID#>

Best�tigungs-Schl�ssel: <#CODE#>

Bitte kopieren Sie diese Werte und f�ge Sie sie in die richtigen Felder durch Einf�gen oder manuelle Eingabe ein.

Sobald die Aktivierung fertig gestellt ist, k�nnen Sie sich mit Ihrem neuen Passwort (untenstehend) wieder einloggen. Sie k�nnen dieses Passwort jederzeit in Ihrem pers�nlichen Kontroll Panel �ndern.

------------------------------------------------
             IHR NEUES PASSWORT
------------------------------------------------

Ihr neues Passwort lautet: <#PASSWORD#>

Verwahren Sie dieses Passwort sicher. Vergessen Sie bitte nicht, dass Sie Ihren Account wieder aktivieren m�ssen, bevor Sie dieses Passwort verwenden k�nnen.

------------------------------------------------
             EIN FEHLER TRITT AUF
------------------------------------------------

Sollten Sie Ihren Account nicht wieder aktivieren k�nnen, kann es m�glich sein, dass Ihr Account entfernt wurde oder dass Sie in einem anderen Aktivierungs-Prozess sind, wie z.B. Registrierung oder E-Mail Adressenwechsel.
Sollte dies der Fall sein, bitte beenden Sie diesen Prozess vorher.
Sollte dieses Problem weiterhin bestehen, kontaktieren Sie einen Administrator um dieses Problem zu l�sen.


EOF;

$EMAIL['newemail'] = <<<EOF
<#NAME#>,
Diese E-Mail wurde Ihnen von <#BOARD_ADDRESS#> gesendet.

Sie erhalten diese E-Mail weil Sie eine andere E-Mail Adresse verwenden m�chten.

------------------------------------------------
        ANWEISUNGEN FOLGEN UNTEN
------------------------------------------------

Wir m�chten, dass Sie Ihre "E-Mail Adressen�nderung" Anfrage "best�tigen", damit wir sicher gehen k�nnen, dass die von Ihnen angegebene E-Mail Adresse korrekt ist. Dies sch�tzt vor ungewolltem Spam und sonstigen Missbrauch.

Sollten Sie das Fenster nicht offen haben, klicken Sie bitte auf den folgenden Link:

<#MAN_LINK#>

(AOL E-Mail Benutzer m�ssen den Link vielleicht kopieren und im Browser wieder einf�gen).

Sie werden nach einer ID und einem Best�tigungs-Schl�ssel gefragt. Dieser lautet:

Benutzer ID: <#ID#>

Best�tigungs-Schl�ssel: <#CODE#>

Bitte kopieren Sie diese Werte und f�ge Sie sie in die richtigen Felder durch Einf�gen oder manuelle Eingabe ein.

Sobald die Aktivierung fertig gestellt ist, wird Ihre neue E-Mail Adresse in unserer Datenbank gespeichert.


------------------------------------------------
            EIN FEHLER TRITT AUF
------------------------------------------------

Solltest Sie Ihren Account nicht wieder aktivieren k�nnen, kann es m�glich sein, dass Ihr Account entfernt wurde oder dass Sie in einem anderen Aktivierungs-Prozess sind, wie z.B. Registrierung oder E-Mail Adressenwechsel.
Sollte dies der Fall sein, bitte beenden Sie diesen Prozess vorher.
Sollte dieses Problem weiterhin bestehen, kontaktieren Sie einen Administrator um dieses Problem zu l�sen.

EOF;

$EMAIL['forward_page'] = <<<EOF
<#TO_NAME#>


<#THE_MESSAGE#>

---------------------------------------------------
Beachten Sie bitte das <#BOARD_NAME#> nicht f�r den Inhalt dieser Mitteilung verantwortlich ist.
---------------------------------------------------

EOF;

$EMAIL['subs_with_post'] = <<<EOF
<#NAME#>,

<#POSTER#> hat einen Beitrag zu einem Ihrer abonnierten Themen geschrieben. "<#TITLE#>".

----------------------------------------------------------------------
<#POST#>
----------------------------------------------------------------------

Das Thema finden Sie hier:
<#BOARD_ADDRESS#>?act=ST&f=<#FORUM_ID#>&t=<#TOPIC_ID#>



Es kann sein, dass dort mehr als nur eine neue Antwort zu dem Thema geschrieben wurde. Um aber unn�tige E-Mails zu vermeiden wird t�glich nur eine Benachrichtigung �ber Ihre Inbox geschickt.

Abonnement l�schen:
--------------

Wenn Sie keine Benachrichtigung mehr zu diesem Thema erhalten m�chten, k�nnen Sie das Abonnement in Ihrem Kontroll Panel l�schen.

EOF;

$EMAIL['subs_new_topic'] = <<<EOF
<#NAME#>,

<#POSTER#> hat ein neues Thema mit dem Titel "<#TITLE#>" im Forum "<#FORUM#>" er�ffnet.

Das Thema finden Sie unter:
<#BOARD_ADDRESS#>?act=ST&f=<#FORUM_ID#>&t=<#TOPIC_ID#>

Es kann sein, dass dort mehr als nur eine neue Antwort zu dem Thema geschrieben wurde. Um aber unn�tige E-Mails zu vermeiden wird t�glich nur eine Benachrichtigung �ber Ihre Inbox geschickt.
<#BOARD_ADDRESS#>?act=Track&f=<#FORUM_ID#>&t=<#TOPIC_ID#>


Abonnement l�schen:
--------------

Wenn Sie keine Benachrichtigung mehr zu diesem Thema erhalten m�chten, k�nnen Sie das Abonnement in Ihrem Kontroll Panel l�schen.
EOF;

$EMAIL['subs_no_post'] = <<<EOF
<#NAME#>,

<#POSTER#> hat einen Beitrag zu einem Ihrer abonnierten Themen geschrieben. "<#TITLE#>".

Das Thema finden Sie hier:
<#BOARD_ADDRESS#>?act=ST&f=<#FORUM_ID#>&t=<#TOPIC_ID#>

Es kann sein, dass dort mehr als nur eine neue Antwort zu dem Thema geschrieben wurde. Um aber unn�tige E-Mails zu vermeiden wird t�glich nur eine Benachrichtigung �ber Ihre Inbox geschickt.

Abonnement l�schen:
--------------

Wenn Sie keine Benachrichtigung mehr zu diesem Thema erhalten m�chten, k�nnen Sie das Abonnement in Ihrem Kontroll Panel l�schen.

EOF;

$EMAIL['email_member'] = <<<EOF
<#MEMBER_NAME#>,

Diese E-Mail wurde Ihnen von  <#FROM_NAME#> �ber <#BOARD_ADDRESS#>)
gesendet.

<#MESSAGE#>

---------------------------------------------------
Beachten Sie bitte, dass <#BOARD_NAME#> nicht f�r den Inhalt der Nachricht verantwortlich ist.
---------------------------------------------------


EOF;

$EMAIL['complete_reg'] = <<<EOF
Registrierung erfolgreich!

Ein Administrator hat soeben Ihre Registrierung oder E-Mail Adress�nderung von <#BOARD_NAME#> best�tigt. Sie k�nnen sich nun mit Ihrem Benutzernamen und Passwort unter <#BOARD_ADDRESS#> einloggen.

EOF;


?>