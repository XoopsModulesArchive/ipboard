<?php

$lang = array (

'topic_text'   => "Hier finden Sie die Beitr�ge.",
'results_title'   => "Suchergebnisse",
'choose_file'   => "W�hlen Sie einen Beitrag",
'help_txt'   => "Willkommen in der Hilfedatenbank.<br><br>Sie k�nnen die Hilfe �ber die Beitragstitel oder die Suche nutzen.",
'submit'   => "Suchen!",
'search_txt'   => "Geben Sie einen Suchbegriff ein",
'search_results'   => "Suchergebnisse",
'results_txt'   => "Hier sind die Suchergebnisse.",
'help_topics'   => "Hilfethemen",
'no_results'   => "Es konnte kein Hilfeeintrag gefunden werden. Versuchen Sie es erneut.",
'help_topic'   => "Hilfethema",
'page_title'   => "Hilfe",

);

?>